//
//  testSDKpod.h
//  testSDKpod
//
//  Created by Jacek Kurbiel on 22/01/2020.
//  Copyright © 2020 Jacek Kurbiel. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for testSDKpod.
FOUNDATION_EXPORT double testSDKpodVersionNumber;

//! Project version string for testSDKpod.
FOUNDATION_EXPORT const unsigned char testSDKpodVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <testSDKpod/PublicHeader.h>


